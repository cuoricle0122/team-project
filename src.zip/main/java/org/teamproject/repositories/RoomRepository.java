package org.teamproject.repositories;

public class RoomRepository {
}

// 객실 리포지토리

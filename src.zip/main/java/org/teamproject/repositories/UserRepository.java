package org.teamproject.repositories;

public class UserRepository {
}

// 사용자 리포지토리

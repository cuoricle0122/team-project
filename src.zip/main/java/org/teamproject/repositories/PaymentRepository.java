package org.teamproject.repositories;

public class PaymentRepository {
}

package org.teamproject.repositories;

public class ReservationRepository {
}

// 예약 리포지토리

package org.teamproject.repositories;

public class HotelRepository {
}

// 호텔 리포지토리

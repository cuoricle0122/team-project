package org.teamproject.repositories;

public class ReviewRepository {
}

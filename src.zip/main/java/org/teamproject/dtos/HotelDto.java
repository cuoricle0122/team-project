package org.teamproject.dtos;

public class HotelDto {
}

// 호텔 관련 DTO
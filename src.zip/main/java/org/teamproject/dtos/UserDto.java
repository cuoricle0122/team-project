package org.teamproject.dtos;

public class UserDto {
}

// 사용자 관련 DTO
package org.teamproject.dtos;

public class PaymentDto {
}

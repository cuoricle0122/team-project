package org.teamproject.dtos;

public class AdminDto {
}

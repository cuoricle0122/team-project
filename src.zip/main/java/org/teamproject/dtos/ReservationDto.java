package org.teamproject.dtos;

public class ReservationDto {
}

// 예약 관련 DTO

package org.teamproject.dtos;

public class NotificationDto {
}

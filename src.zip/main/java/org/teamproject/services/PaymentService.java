package org.teamproject.services;

public class PaymentService {
}

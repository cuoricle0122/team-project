package org.teamproject.services;

public class HotelService {
}

// 호텔 서비스

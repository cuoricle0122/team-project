package org.teamproject.services;

public class AdminService {
}

package org.teamproject.configs;

public class SecurityConfig {
}

// Spring MVC 설정
package org.teamproject.configs;

import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

public class MvcConfig implements WebMvcConfigurer {
}

// 보안 설정 클래스
package org.teamproject.controller;

public class ReservationController {
}

// 예약 관련 컨트롤러
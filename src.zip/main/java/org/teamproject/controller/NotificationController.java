package org.teamproject.controller;

public class NotificationController {
}

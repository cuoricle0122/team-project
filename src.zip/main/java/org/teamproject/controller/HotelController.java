package org.teamproject.controller;

public class HotelController {
}

// 호텔 관련 컨트롤러
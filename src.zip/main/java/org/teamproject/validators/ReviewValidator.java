package org.teamproject.validators;

public class ReviewValidator {
}

package org.teamproject.validators;

public class ReservationValidator {
}

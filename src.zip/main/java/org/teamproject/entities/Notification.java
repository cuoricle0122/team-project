package org.teamproject.entities;

public class Notification {
}

package org.teamproject.entities;

public class Room {
}

// 객실 엔터티

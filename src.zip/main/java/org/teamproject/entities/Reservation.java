package org.teamproject.entities;

public class Reservation {
}

// 예약 엔터티

package org.teamproject.entities;

public class Hotel {
}

// 호텔 엔터티

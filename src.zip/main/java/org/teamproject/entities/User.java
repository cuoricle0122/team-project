package org.teamproject.entities;

public class User {
}

// 사용자 엔터티